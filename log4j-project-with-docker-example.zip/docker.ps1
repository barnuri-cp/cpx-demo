docker build -t test .
docker rm -f test
docker run --rm  --name test -p 9900:9900 test
